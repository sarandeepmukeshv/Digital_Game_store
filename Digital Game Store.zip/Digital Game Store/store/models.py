import uuid
from django.db import models
from django.contrib.auth.models import User
from django.utils.text import slugify

class Genre(models.Model):
    name = models.CharField(max_length=100)
    slug = models.SlugField(unique=True, blank=True)
    icon = models.CharField(max_length=50, default='fa-gamepad', help_text="FontAwesome icon class name e.g. fa-fire, fa-dragon")
    description = models.TextField(blank=True)

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name

class Tag(models.Model):
    name = models.CharField(max_length=50)
    slug = models.SlugField(unique=True, blank=True)

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name

class Game(models.Model):
    title = models.CharField(max_length=200)
    slug = models.SlugField(unique=True, blank=True)
    tagline = models.CharField(max_length=255, help_text="Short engaging hook")
    description = models.TextField()
    developer = models.CharField(max_length=150)
    publisher = models.CharField(max_length=150)
    release_date = models.DateField()
    
    price = models.DecimalField(max_digits=8, decimal_places=2)
    discount_percent = models.IntegerField(default=0, help_text="Discount percentage (0-99)")
    
    is_featured = models.BooleanField(default=False)
    is_trending = models.BooleanField(default=False)
    is_banner = models.BooleanField(default=False, help_text="Featured in home hero banner carousel")
    
    cover_image = models.URLField(max_length=500, help_text="Vertical poster image URL")
    banner_image = models.URLField(max_length=500, help_text="Wide landscape banner image URL")
    trailer_url = models.URLField(max_length=500, blank=True, help_text="YouTube embed or MP4 video URL")
    
    genres = models.ManyToManyField(Genre, related_name='games')
    tags = models.ManyToManyField(Tag, related_name='games', blank=True)
    
    # Minimum System Requirements
    min_os = models.CharField(max_length=100, default="Windows 10 64-bit")
    min_processor = models.CharField(max_length=150, default="Intel Core i5-6600K / AMD Ryzen 5 1600")
    min_memory = models.CharField(max_length=50, default="8 GB RAM")
    min_graphics = models.CharField(max_length=150, default="NVIDIA GeForce GTX 1060 / AMD Radeon RX 580")
    min_storage = models.CharField(max_length=50, default="50 GB available space")
    
    # Recommended System Requirements
    rec_os = models.CharField(max_length=100, default="Windows 11 64-bit")
    rec_processor = models.CharField(max_length=150, default="Intel Core i7-12700K / AMD Ryzen 7 7800X3D")
    rec_memory = models.CharField(max_length=50, default="16 GB RAM")
    rec_graphics = models.CharField(max_length=150, default="NVIDIA GeForce RTX 4070 / AMD Radeon RX 7800 XT")
    rec_storage = models.CharField(max_length=50, default="50 GB SSD available space")
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.title)
        super().save(*args, **kwargs)

    @property
    def discounted_price(self):
        if self.discount_percent > 0:
            discount = (self.price * self.discount_percent) / 100
            return round(self.price - discount, 2)
        return self.price

    @property
    def savings_amount(self):
        if self.discount_percent > 0:
            return round(self.price - self.discounted_price, 2)
        return 0.00

    @property
    def average_rating(self):
        reviews = self.reviews.all()
        if reviews.exists():
            return round(sum(r.rating for r in reviews) / reviews.count(), 1)
        return 4.5  # default baseline score

    @property
    def positive_review_percent(self):
        reviews = self.reviews.all()
        if reviews.exists():
            positive = reviews.filter(is_recommended=True).count()
            return int((positive / reviews.count()) * 100)
        return 92  # default baseline positive percentage

    def __str__(self):
        return self.title

class GameScreenshot(models.Model):
    game = models.ForeignKey(Game, on_delete=models.CASCADE, related_name='screenshots')
    image_url = models.URLField(max_length=500)
    caption = models.CharField(max_length=200, blank=True)

    def __str__(self):
        return f"{self.game.title} - Screenshot"

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    avatar_url = models.URLField(max_length=500, default="https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=300")
    wallet_balance = models.DecimalField(max_digits=10, decimal_places=2, default=100.00)
    bio = models.TextField(blank=True, default="Passionate Gamer & Cyber Explorer.")

    def __str__(self):
        return f"{self.user.username}'s Profile"

class Wishlist(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='wishlist')
    game = models.ForeignKey(Game, on_delete=models.CASCADE, related_name='wishlisted_by')
    added_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'game')

    def __str__(self):
        return f"{self.user.username} - {self.game.title}"

class Cart(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True, related_name='carts')
    session_key = models.CharField(max_length=100, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Cart ({self.user.username if self.user else self.session_key})"

    @property
    def total_price(self):
        return sum(item.game.discounted_price for item in self.items.all())

class CartItem(models.Model):
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE, related_name='items')
    game = models.ForeignKey(Game, on_delete=models.CASCADE)
    added_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('cart', 'game')

    def __str__(self):
        return f"{self.game.title} in Cart"

class Order(models.Model):
    PAYMENT_CHOICES = (
        ('wallet', 'Store Wallet Balance'),
        ('credit_card', 'Credit / Debit Card'),
        ('paypal', 'PayPal'),
    )
    STATUS_CHOICES = (
        ('completed', 'Completed'),
        ('refunded', 'Refunded'),
        ('pending', 'Pending'),
    )

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='orders')
    order_number = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    payment_method = models.CharField(max_length=30, choices=PAYMENT_CHOICES, default='wallet')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='completed')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Order #{str(self.order_number)[:8]} - {self.user.username}"

class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='items')
    game = models.ForeignKey(Game, on_delete=models.CASCADE)
    price_at_purchase = models.DecimalField(max_digits=8, decimal_places=2)
    license_key = models.CharField(max_length=50, blank=True)

    def save(self, *args, **kwargs):
        if not self.license_key:
            # Generate key format: XXXX-YYYY-ZZZZ-AAAA
            k = str(uuid.uuid4()).upper().split('-')
            self.license_key = f"{k[0][:4]}-{k[1][:4]}-{k[2][:4]}-{k[3][:4]}"
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.game.title} (Key: {self.license_key})"

class Review(models.Model):
    game = models.ForeignKey(Game, on_delete=models.CASCADE, related_name='reviews')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='reviews')
    rating = models.IntegerField(default=5, help_text="1 to 5 rating")
    is_recommended = models.BooleanField(default=True, help_text="Thumbs up / Thumbs down")
    title = models.CharField(max_length=150)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    helpful_votes = models.IntegerField(default=0)

    def __str__(self):
        return f"Review for {self.game.title} by {self.user.username}"
