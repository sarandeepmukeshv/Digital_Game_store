import datetime
from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from store.models import Genre, Tag, Game, GameScreenshot, UserProfile, Order, OrderItem, Review

class Command(BaseCommand):
    help = "Seed database with realistic digital game store data, sample users, and orders"

    def handle(self, *args, **options):
        self.stdout.write(self.style.WARNING("Seeding store database..."))

        # Create Admin user
        admin_user, _ = User.objects.get_or_create(
            username='admin',
            defaults={
                'email': 'admin@nexusgames.com',
                'is_staff': True,
                'is_superuser': True,
            }
        )
        admin_user.set_password('admin123')
        admin_user.save()
        UserProfile.objects.get_or_create(user=admin_user, defaults={'wallet_balance': 500.00})

        # Create Gamer user
        gamer_user, _ = User.objects.get_or_create(
            username='gamer',
            defaults={
                'email': 'alex.gamer@example.com',
                'first_name': 'Alex',
                'last_name': 'Mercer',
            }
        )
        gamer_user.set_password('password123')
        gamer_user.save()
        UserProfile.objects.get_or_create(
            user=gamer_user,
            defaults={
                'wallet_balance': 250.00,
                'avatar_url': 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300',
                'bio': 'Hardcore RPG enthusiast & Sci-Fi lover.'
            }
        )

        # Genres
        genres_data = [
            {'name': 'Action', 'icon': 'fa-bolt', 'description': 'Fast-paced adrenaline combat and shooting.'},
            {'name': 'RPG', 'icon': 'fa-dragon', 'description': 'Immersive open worlds, deep storylines, and character progression.'},
            {'name': 'Cyberpunk & Sci-Fi', 'icon': 'fa-microchip', 'description': 'Futuristic dystopias, neon cities, and space exploration.'},
            {'name': 'Strategy', 'icon': 'fa-chess-king', 'description': 'Tactical depth, empire building, and strategic planning.'},
            {'name': 'Open World', 'icon': 'fa-globe-americas', 'description': 'Vast unscripted landscapes to explore freely.'},
            {'name': 'Indie', 'icon': 'fa-gamepad', 'description': 'Creative, innovative titles from independent game studios.'},
        ]
        genres_dict = {}
        for g_data in genres_data:
            g_obj, _ = Genre.objects.get_or_create(name=g_data['name'], defaults=g_data)
            genres_dict[g_data['name']] = g_obj

        # Tags
        tags_list = ['Singleplayer', 'Co-op', 'Multiplayer', 'Ray Tracing', 'VR Supported', 'Controller Support', 'Atmospheric', 'Sci-Fi']
        tags_dict = {}
        for t_name in tags_list:
            t_obj, _ = Tag.objects.get_or_create(name=t_name)
            tags_dict[t_name] = t_obj

        # Games Data
        games_data = [
            {
                'title': 'Cyberpunk Nexus 2088',
                'tagline': 'Hack the Grid. Rule the Neon Underworld.',
                'description': 'Cyberpunk Nexus 2088 is an action-packed open-world RPG set in the mega-city of Neo-Veridia. Play as Kael, a mercenary netrunner who discovers a corporate conspiracy threatening to erase human consciousness. Featuring cutting-edge real-time ray tracing, deep skill trees, cybernetic augmentations, and multiple branch endings.',
                'developer': 'Vaporworks Games',
                'publisher': 'Nexus Interactive',
                'release_date': datetime.date(2025, 11, 15),
                'price': 59.99,
                'discount_percent': 35,
                'is_featured': True,
                'is_trending': True,
                'is_banner': True,
                'cover_image': 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800',
                'banner_image': 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=1600',
                'trailer_url': 'https://www.youtube.com/embed/dQw4w9WgXcQ',
                'genres': ['Action', 'RPG', 'Cyberpunk & Sci-Fi', 'Open World'],
                'tags': ['Singleplayer', 'Ray Tracing', 'Atmospheric', 'Sci-Fi'],
                'min_specs': {'min_os': 'Windows 10 64-bit', 'min_processor': 'Intel Core i5-10400F', 'min_memory': '16 GB RAM', 'min_graphics': 'NVIDIA RTX 2060 (6GB)', 'min_storage': '70 GB SSD'},
                'rec_specs': {'rec_os': 'Windows 11 64-bit', 'rec_processor': 'Intel Core i7-13700K', 'rec_memory': '32 GB RAM', 'rec_graphics': 'NVIDIA RTX 4080 (16GB)', 'rec_storage': '70 GB NVMe SSD'},
                'screenshots': [
                    'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?w=1200',
                    'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=1200',
                    'https://images.unsplash.com/photo-1563089145-599997674d42?w=1200'
                ]
            },
            {
                'title': 'Elden Myth: Shadows of Asgard',
                'tagline': 'Claim the divine throne of fallen Nordic Gods.',
                'description': 'A dark tactical action-RPG blending Norse mythology with souls-like combat mastery. Wield legendary weapons infused with elemental runes, battle massive mythic titans across fractured realms, and forge your destiny in an unforgiving dark fantasy landscape.',
                'developer': 'Ironclad Studios',
                'publisher': 'Asgard Digital',
                'release_date': datetime.date(2025, 4, 10),
                'price': 69.99,
                'discount_percent': 20,
                'is_featured': True,
                'is_trending': True,
                'is_banner': True,
                'cover_image': 'https://images.unsplash.com/photo-1579373903781-fd5c0c30c4cd?w=800',
                'banner_image': 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1600',
                'trailer_url': 'https://www.youtube.com/embed/dQw4w9WgXcQ',
                'genres': ['Action', 'RPG', 'Open World'],
                'tags': ['Singleplayer', 'Co-op', 'Controller Support'],
                'min_specs': {'min_os': 'Windows 10 64-bit', 'min_processor': 'AMD Ryzen 5 3600', 'min_memory': '12 GB RAM', 'min_graphics': 'GTX 1660 Super', 'min_storage': '85 GB SSD'},
                'rec_specs': {'rec_os': 'Windows 11 64-bit', 'rec_processor': 'AMD Ryzen 7 7800X3D', 'rec_memory': '32 GB RAM', 'rec_graphics': 'NVIDIA RTX 4070 Super', 'rec_storage': '85 GB SSD'},
                'screenshots': [
                    'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1200',
                    'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=1200'
                ]
            },
            {
                'title': 'Starvoid Odyssey',
                'tagline': 'Infinite Galaxies. Unlimited Frontier.',
                'description': 'Embark on the ultimate interstellar sandbox experience. Command customizable capital ships, build orbital megastructures, trade with alien syndicates, and wage warp-speed fleet battles in a persistent, player-driven universe.',
                'developer': 'Starlight Dynamics',
                'publisher': 'Nexus Interactive',
                'release_date': datetime.date(2025, 9, 1),
                'price': 49.99,
                'discount_percent': 40,
                'is_featured': True,
                'is_trending': False,
                'is_banner': True,
                'cover_image': 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800',
                'banner_image': 'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=1600',
                'trailer_url': 'https://www.youtube.com/embed/dQw4w9WgXcQ',
                'genres': ['Cyberpunk & Sci-Fi', 'Open World', 'Strategy'],
                'tags': ['Multiplayer', 'VR Supported', 'Sci-Fi'],
                'min_specs': {'min_os': 'Windows 10', 'min_processor': 'i5-8400', 'min_memory': '8 GB RAM', 'min_graphics': 'GTX 1070', 'min_storage': '60 GB'},
                'rec_specs': {'rec_os': 'Windows 11', 'rec_processor': 'i7-12700', 'rec_memory': '16 GB RAM', 'rec_graphics': 'RTX 3080', 'rec_storage': '60 GB SSD'},
                'screenshots': [
                    'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=1200'
                ]
            },
            {
                'title': 'Neon Drift: Tokyo Rush',
                'tagline': 'High-octane synthwave racing through rain-slicked mega highways.',
                'description': 'Precision street racing meets futuristic anti-gravity physics. Tune exotic hypercars with particle trails, compete in night tournaments across glowing Japanese skylines, and dominate online leaderboards.',
                'developer': 'Velocity Craft',
                'publisher': 'Apex Games',
                'release_date': datetime.date(2025, 8, 20),
                'price': 29.99,
                'discount_percent': 50,
                'is_featured': True,
                'is_trending': True,
                'is_banner': False,
                'cover_image': 'https://images.unsplash.com/photo-1511919884226-fd3cad34687c?w=800',
                'banner_image': 'https://images.unsplash.com/photo-1544829099-b9a0c07fad1a?w=1600',
                'trailer_url': 'https://www.youtube.com/embed/dQw4w9WgXcQ',
                'genres': ['Action', 'Cyberpunk & Sci-Fi'],
                'tags': ['Multiplayer', 'Controller Support', 'Ray Tracing'],
                'min_specs': {'min_os': 'Windows 10', 'min_processor': 'i5 7th Gen', 'min_memory': '8 GB RAM', 'min_graphics': 'GTX 1050Ti', 'min_storage': '30 GB'},
                'rec_specs': {'rec_os': 'Windows 11', 'rec_processor': 'i7 11th Gen', 'rec_memory': '16 GB RAM', 'rec_graphics': 'RTX 3070', 'rec_storage': '30 GB SSD'},
                'screenshots': [
                    'https://images.unsplash.com/photo-1544829099-b9a0c07fad1a?w=1200'
                ]
            },
            {
                'title': 'Galactic Command: Sector 7',
                'tagline': 'Master turn-based tactical warfare across star systems.',
                'description': 'A deep 4X space strategy game. Command fleets, manage orbital colonies, engage in intricate diplomatic espionage, and conquer deep space threats.',
                'developer': 'Aegis Mind',
                'publisher': 'Nexus Interactive',
                'release_date': datetime.date(2025, 2, 1),
                'price': 39.99,
                'discount_percent': 15,
                'is_featured': False,
                'is_trending': False,
                'is_banner': False,
                'cover_image': 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800',
                'banner_image': 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?w=1600',
                'trailer_url': 'https://www.youtube.com/embed/dQw4w9WgXcQ',
                'genres': ['Strategy', 'Cyberpunk & Sci-Fi'],
                'tags': ['Singleplayer', 'Multiplayer'],
                'min_specs': {'min_os': 'Windows 10', 'min_processor': 'i3-9100', 'min_memory': '8 GB RAM', 'min_graphics': 'GTX 960', 'min_storage': '25 GB'},
                'rec_specs': {'rec_os': 'Windows 11', 'rec_processor': 'i5-12400', 'rec_memory': '16 GB RAM', 'rec_graphics': 'RTX 2070', 'rec_storage': '25 GB SSD'},
                'screenshots': []
            },
            {
                'title': 'Pixel Dungeon Crawler: Reborn',
                'tagline': 'Charming retro roguelike procedurally generated adventure.',
                'description': 'Hand-crafted pixel art meets endless replayability! Dive into perilous dungeons, collect hundreds of elemental relics, combine spell cards, and defeat legendary boss guardians.',
                'developer': 'BitForge Studios',
                'publisher': 'Indie Vault',
                'release_date': datetime.date(2025, 6, 12),
                'price': 14.99,
                'discount_percent': 10,
                'is_featured': True,
                'is_trending': True,
                'is_banner': False,
                'cover_image': 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800',
                'banner_image': 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=1600',
                'trailer_url': 'https://www.youtube.com/embed/dQw4w9WgXcQ',
                'genres': ['Indie', 'RPG'],
                'tags': ['Singleplayer', 'Co-op', 'Controller Support'],
                'min_specs': {'min_os': 'Windows 7/10/11', 'min_processor': 'Dual Core 2GHz', 'min_memory': '4 GB RAM', 'min_graphics': 'Integrated Graphics', 'min_storage': '2 GB'},
                'rec_specs': {'rec_os': 'Windows 10/11', 'rec_processor': 'Quad Core 3GHz', 'rec_memory': '8 GB RAM', 'rec_graphics': 'GTX 750Ti', 'rec_storage': '2 GB SSD'},
                'screenshots': []
            },
            {
                'title': 'Chrono Blade: Void Warrior',
                'tagline': 'Time-bending hack-and-slash melee action.',
                'description': 'Freeze time, slice through hordes of abyssal void demons, and rewind fatal strikes in lightning-fast 60FPS combat.',
                'developer': 'Slashworks',
                'publisher': 'Indie Vault',
                'release_date': datetime.date(2025, 10, 5),
                'price': 24.99,
                'discount_percent': 25,
                'is_featured': False,
                'is_trending': True,
                'is_banner': False,
                'cover_image': 'https://images.unsplash.com/photo-1563089145-599997674d42?w=800',
                'banner_image': 'https://images.unsplash.com/photo-1563089145-599997674d42?w=1600',
                'trailer_url': '',
                'genres': ['Action', 'Indie'],
                'tags': ['Singleplayer', 'Controller Support'],
                'min_specs': {'min_os': 'Windows 10', 'min_processor': 'i5-6400', 'min_memory': '8 GB RAM', 'min_graphics': 'GTX 1060', 'min_storage': '15 GB'},
                'rec_specs': {'rec_os': 'Windows 11', 'rec_processor': 'i7-9700', 'rec_memory': '16 GB RAM', 'rec_graphics': 'RTX 3060', 'rec_storage': '15 GB SSD'},
                'screenshots': []
            },
            {
                'title': 'Valor & Glory: Strike Ops',
                'tagline': 'Tactical competitive 5v5 shooter precision mastery.',
                'description': 'High-stakes tactical FPS with destructible environments, realistic gunplay mechanics, and agent abilities.',
                'developer': 'Vanguard Interactive',
                'publisher': 'Apex Games',
                'release_date': datetime.date(2025, 1, 15),
                'price': 0.00,
                'discount_percent': 0,
                'is_featured': True,
                'is_trending': True,
                'is_banner': False,
                'cover_image': 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800',
                'banner_image': 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=1600',
                'trailer_url': '',
                'genres': ['Action'],
                'tags': ['Multiplayer', 'Co-op', 'Controller Support'],
                'min_specs': {'min_os': 'Windows 10', 'min_processor': 'i5-4460', 'min_memory': '8 GB RAM', 'min_graphics': 'GTX 1050', 'min_storage': '40 GB'},
                'rec_specs': {'rec_os': 'Windows 11', 'rec_processor': 'i7-10700', 'rec_memory': '16 GB RAM', 'rec_graphics': 'RTX 3060Ti', 'rec_storage': '40 GB SSD'},
                'screenshots': []
            }
        ]

        created_games = []
        for item in games_data:
            genres = item.pop('genres')
            tags = item.pop('tags')
            screenshots = item.pop('screenshots')
            min_specs = item.pop('min_specs')
            rec_specs = item.pop('rec_specs')

            game, created = Game.objects.get_or_create(
                title=item['title'],
                defaults={**item, **min_specs, **rec_specs}
            )
            for g_name in genres:
                if g_name in genres_dict:
                    game.genres.add(genres_dict[g_name])
            for t_name in tags:
                if t_name in tags_dict:
                    game.tags.add(tags_dict[t_name])

            for s_url in screenshots:
                GameScreenshot.objects.get_or_create(game=game, image_url=s_url)

            created_games.append(game)

        # Seed initial order and reviews for sample user 'gamer'
        if created_games:
            # Create a sample completed order
            order = Order.objects.create(
                user=gamer_user,
                total_amount=created_games[0].discounted_price + created_games[1].discounted_price,
                payment_method='wallet',
                status='completed'
            )
            OrderItem.objects.create(order=order, game=created_games[0], price_at_purchase=created_games[0].discounted_price)
            OrderItem.objects.create(order=order, game=created_games[1], price_at_purchase=created_games[1].discounted_price)

            # Create sample reviews
            Review.objects.get_or_create(
                game=created_games[0],
                user=gamer_user,
                defaults={
                    'rating': 5,
                    'is_recommended': True,
                    'title': 'An absolute masterpiece of cyberpunk aesthetics!',
                    'content': 'The graphics and ray tracing in Neo-Veridia are breathtaking. Combat feels smooth and netrunning mechanics are incredibly rewarding. Highly recommended!',
                    'helpful_votes': 142
                }
            )
            Review.objects.get_or_create(
                game=created_games[1],
                user=gamer_user,
                defaults={
                    'rating': 5,
                    'is_recommended': True,
                    'title': 'Challenging, dark, and beautifully crafted Norse combat.',
                    'content': 'Boss fights are epic and unforgiving. Perfect for anyone who loves souls-like games with rich Nordic lore.',
                    'helpful_votes': 89
                }
            )

        self.stdout.write(self.style.SUCCESS("Successfully seeded digital game store database!"))
