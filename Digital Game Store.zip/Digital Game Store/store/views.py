import uuid
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q, Count, Avg, Sum
from django.core.paginator import Paginator
from django.http import JsonResponse

from .models import Genre, Tag, Game, GameScreenshot, UserProfile, Wishlist, Cart, CartItem, Order, OrderItem, Review

def get_or_create_cart(request):
    if request.user.is_authenticated:
        cart, _ = Cart.objects.get_or_create(user=request.user)
    else:
        if not request.session.session_key:
            request.session.save()
        session_key = request.session.session_key
        cart, _ = Cart.objects.get_or_create(session_key=session_key)
    return cart

def home_view(request):
    banner_games = Game.objects.filter(is_banner=True)[:4]
    if not banner_games.exists():
        banner_games = Game.objects.all()[:4]

    trending_games = Game.objects.filter(is_trending=True)[:6]
    featured_games = Game.objects.filter(is_featured=True)[:6]
    deal_games = Game.objects.filter(discount_percent__gt=0).order_by('-discount_percent')[:6]
    new_releases = Game.objects.all().order_by('-release_date')[:6]
    genres = Genre.objects.annotate(game_count=Count('games')).all()

    context = {
        'banner_games': banner_games,
        'trending_games': trending_games,
        'featured_games': featured_games,
        'deal_games': deal_games,
        'new_releases': new_releases,
        'genres': genres,
    }
    return render(request, 'store/home.html', context)

def catalog_view(request):
    query = request.GET.get('q', '')
    genre_slug = request.GET.get('genre', '')
    tag_slug = request.GET.get('tag', '')
    max_price = request.GET.get('max_price', '')
    sort_by = request.GET.get('sort', 'trending')

    games = Game.objects.all()

    if query:
        games = games.filter(
            Q(title__icontains=query) |
            Q(description__icontains=query) |
            Q(developer__icontains=query) |
            Q(publisher__icontains=query)
        )

    if genre_slug:
        games = games.filter(genres__slug=genre_slug)

    if tag_slug:
        games = games.filter(tags__slug=tag_slug)

    if max_price:
        try:
            val = float(max_price)
            # filter based on discounted price logic in query (approx price <= val)
            games = games.filter(price__lte=val)
        except ValueError:
            pass

    # Sorting
    if sort_by == 'price_low':
        games = games.order_by('price')
    elif sort_by == 'price_high':
        games = games.order_by('-price')
    elif sort_by == 'newest':
        games = games.order_by('-release_date')
    elif sort_by == 'discount':
        games = games.order_by('-discount_percent')
    else:  # default trending
        games = games.order_by('-is_trending', '-is_featured', '-release_date')

    games = games.distinct()

    paginator = Paginator(games, 9)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    genres = Genre.objects.all()
    tags = Tag.objects.all()

    context = {
        'games': page_obj,
        'page_obj': page_obj,
        'genres': genres,
        'tags': tags,
        'query': query,
        'selected_genre': genre_slug,
        'selected_tag': tag_slug,
        'selected_sort': sort_by,
        'max_price': max_price,
    }
    return render(request, 'store/catalog.html', context)

def game_detail_view(request, slug):
    game = get_object_or_404(Game, slug=slug)
    screenshots = game.screenshots.all()
    reviews = game.reviews.all().order_by('-created_at')
    
    # Related games
    related_games = Game.objects.filter(genres__in=game.genres.all()).exclude(id=game.id).distinct()[:4]

    is_owned = False
    in_wishlist = False

    if request.user.is_authenticated:
        is_owned = OrderItem.objects.filter(order__user=request.user, game=game, order__status='completed').exists()
        in_wishlist = Wishlist.objects.filter(user=request.user, game=game).exists()

    # Submit review
    if request.method == 'POST':
        if not request.user.is_authenticated:
            messages.warning(request, "Please log in to submit a review.")
            return redirect('login')
        
        rating = int(request.POST.get('rating', 5))
        is_rec = request.POST.get('is_recommended') == 'true'
        title = request.POST.get('title', '').strip()
        content = request.POST.get('content', '').strip()

        if title and content:
            Review.objects.update_or_create(
                game=game,
                user=request.user,
                defaults={
                    'rating': rating,
                    'is_recommended': is_rec,
                    'title': title,
                    'content': content,
                }
            )
            messages.success(request, "Your review has been submitted!")
            return redirect('game_detail', slug=slug)

    context = {
        'game': game,
        'screenshots': screenshots,
        'reviews': reviews,
        'related_games': related_games,
        'is_owned': is_owned,
        'in_wishlist': in_wishlist,
    }
    return render(request, 'store/game_detail.html', context)

def cart_view(request):
    cart = get_or_create_cart(request)
    cart_items = cart.items.all().select_related('game')

    subtotal = cart.total_price
    discount_amount = 0
    coupon_code = request.GET.get('coupon', '').strip().upper()

    if coupon_code == 'GAMER20':
        discount_amount = round(subtotal * 0.20, 2)
        messages.success(request, "Coupon 'GAMER20' applied! 20% discount.")
    elif coupon_code == 'CYBER10':
        discount_amount = min(subtotal, 10.00)
        messages.success(request, "Coupon 'CYBER10' applied! $10 discount.")
    elif coupon_code:
        messages.error(request, "Invalid coupon code.")

    total = max(0, subtotal - discount_amount)

    context = {
        'cart': cart,
        'cart_items': cart_items,
        'subtotal': subtotal,
        'discount_amount': discount_amount,
        'total': total,
        'coupon_code': coupon_code,
    }
    return render(request, 'store/cart.html', context)

def cart_add(request, game_id):
    game = get_object_or_404(Game, id=game_id)

    if request.user.is_authenticated:
        if OrderItem.objects.filter(order__user=request.user, game=game, order__status='completed').exists():
            messages.info(request, f"You already own '{game.title}' in your library!")
            return redirect('library')

    cart = get_or_create_cart(request)
    cart_item, created = CartItem.objects.get_or_create(cart=cart, game=game)

    if created:
        messages.success(request, f"Added '{game.title}' to your cart.")
    else:
        messages.info(request, f"'{game.title}' is already in your cart.")

    return redirect('cart')

def cart_remove(request, item_id):
    cart = get_or_create_cart(request)
    item = get_object_or_404(CartItem, id=item_id, cart=cart)
    game_title = item.game.title
    item.delete()
    messages.success(request, f"Removed '{game_title}' from cart.")
    return redirect('cart')

@login_required
def wishlist_view(request):
    wishlist_items = Wishlist.objects.filter(user=request.user).select_related('game')
    context = {
        'wishlist_items': wishlist_items
    }
    return render(request, 'store/wishlist.html', context)

@login_required
def wishlist_toggle(request, game_id):
    game = get_object_or_404(Game, id=game_id)
    wishlist_item = Wishlist.objects.filter(user=request.user, game=game).first()

    if wishlist_item:
        wishlist_item.delete()
        messages.info(request, f"Removed '{game.title}' from your wishlist.")
    else:
        Wishlist.objects.create(user=request.user, game=game)
        messages.success(request, f"Added '{game.title}' to your wishlist!")

    next_url = request.META.get('HTTP_REFERER', '/')
    return redirect(next_url)

@login_required
def checkout_view(request):
    cart = get_or_create_cart(request)
    cart_items = cart.items.all().select_related('game')

    if not cart_items.exists():
        messages.warning(request, "Your cart is empty.")
        return redirect('catalog')

    profile, _ = UserProfile.objects.get_or_create(user=request.user)
    subtotal = cart.total_price
    coupon_code = request.POST.get('coupon_code', '').strip().upper()
    
    discount = 0.00
    if coupon_code == 'GAMER20':
        discount = float(subtotal) * 0.20
    elif coupon_code == 'CYBER10':
        discount = min(float(subtotal), 10.00)

    total_amount = max(0.00, float(subtotal) - discount)

    if request.method == 'POST' and 'confirm_checkout' in request.POST:
        payment_method = request.POST.get('payment_method', 'wallet')

        if payment_method == 'wallet':
            if float(profile.wallet_balance) < total_amount:
                messages.error(request, f"Insufficient wallet balance (${profile.wallet_balance:.2f}). Please top up your wallet or choose another payment method.")
                return redirect('checkout')
            
            # Deduct wallet balance
            profile.wallet_balance = float(profile.wallet_balance) - total_amount
            profile.save()

        # Create Order
        order = Order.objects.create(
            user=request.user,
            total_amount=total_amount,
            payment_method=payment_method,
            status='completed'
        )

        for item in cart_items:
            OrderItem.objects.create(
                order=order,
                game=item.game,
                price_at_purchase=item.game.discounted_price
            )

        # Clear cart
        cart_items.delete()

        messages.success(request, f"Purchase Successful! Digital CD Keys generated for Order #{str(order.order_number)[:8]}.")
        return redirect('order_detail', order_number=order.order_number)

    context = {
        'cart_items': cart_items,
        'subtotal': subtotal,
        'discount': discount,
        'total_amount': total_amount,
        'wallet_balance': profile.wallet_balance,
        'coupon_code': coupon_code,
    }
    return render(request, 'store/checkout.html', context)

@login_required
def order_detail_view(request, order_number):
    order = get_object_or_404(Order, order_number=order_number, user=request.user)
    context = {
        'order': order,
        'items': order.items.all().select_related('game')
    }
    return render(request, 'store/order_detail.html', context)

@login_required
def library_view(request):
    # Owned games from completed orders
    order_items = OrderItem.objects.filter(
        order__user=request.user,
        order__status='completed'
    ).select_related('game').order_by('-order__created_at')

    # Deduplicate games
    owned_dict = {}
    for item in order_items:
        if item.game.id not in owned_dict:
            owned_dict[item.game.id] = {
                'game': item.game,
                'license_key': item.license_key,
                'purchased_at': item.order.created_at
            }

    owned_games = list(owned_dict.values())

    query = request.GET.get('q', '').strip()
    if query:
        owned_games = [g for g in owned_games if query.lower() in g['game'].title.lower()]

    context = {
        'owned_games': owned_games,
        'query': query,
    }
    return render(request, 'store/library.html', context)

@login_required
def profile_view(request):
    profile, _ = UserProfile.objects.get_or_create(user=request.user)
    orders = Order.objects.filter(user=request.user).order_by('-created_at')

    if request.method == 'POST':
        if 'topup_amount' in request.POST:
            try:
                amt = float(request.POST.get('topup_amount', 0))
                if amt > 0:
                    profile.wallet_balance = float(profile.wallet_balance) + amt
                    profile.save()
                    messages.success(request, f"Successfully added ${amt:.2f} to your Store Wallet!")
            except ValueError:
                messages.error(request, "Invalid amount entered.")
            return redirect('profile')

        elif 'update_profile' in request.POST:
            profile.bio = request.POST.get('bio', profile.bio)
            avatar = request.POST.get('avatar_url', '').strip()
            if avatar:
                profile.avatar_url = avatar
            profile.save()
            messages.success(request, "Profile updated successfully.")
            return redirect('profile')

    context = {
        'profile': profile,
        'orders': orders,
    }
    return render(request, 'store/profile.html', context)

@login_required
def publisher_dashboard(request):
    if not request.user.is_staff:
        messages.warning(request, "Publisher portal is reserved for store administrators & publishers.")
        return redirect('home')

    total_revenue = Order.objects.filter(status='completed').aggregate(Sum('total_amount'))['total_amount__sum'] or 0.00
    total_orders = Order.objects.filter(status='completed').count()
    total_games = Game.objects.count()
    total_users = UserProfile.objects.count()

    top_selling = OrderItem.objects.values('game__title').annotate(total_sold=Count('id'), revenue=Sum('price_at_purchase')).order_by('-total_sold')[:5]

    if request.method == 'POST' and 'add_game' in request.POST:
        title = request.POST.get('title')
        tagline = request.POST.get('tagline')
        desc = request.POST.get('description')
        price = request.POST.get('price', 19.99)
        dev = request.POST.get('developer', 'Indie Studio')
        pub = request.POST.get('publisher', 'Nexus Publishing')
        cover = request.POST.get('cover_image', 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800')
        banner = request.POST.get('banner_image', 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=1600')

        if title and desc:
            g = Game.objects.create(
                title=title,
                tagline=tagline or title,
                description=desc,
                price=price,
                developer=dev,
                publisher=pub,
                release_date=datetime.date.today(),
                cover_image=cover,
                banner_image=banner,
            )
            messages.success(request, f"Game '{g.title}' published successfully!")
            return redirect('publisher_dashboard')

    context = {
        'total_revenue': total_revenue,
        'total_orders': total_orders,
        'total_games': total_games,
        'total_users': total_users,
        'top_selling': top_selling,
    }
    return render(request, 'store/publisher.html', context)

def signup_view(request):
    if request.user.is_authenticated:
        return redirect('home')

    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            UserProfile.objects.create(user=user, wallet_balance=100.00)  # $100 welcome bonus!
            login(request, user)
            messages.success(request, f"Welcome to Nexus Games, {user.username}! You received a $100.00 Welcome Store Wallet Bonus!")
            return redirect('home')
    else:
        form = UserCreationForm()

    return render(request, 'registration/signup.html', {'form': form})

def login_view(request):
    if request.user.is_authenticated:
        return redirect('home')

    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, f"Welcome back, {user.username}!")
            next_url = request.GET.get('next', 'home')
            return redirect(next_url)
    else:
        form = AuthenticationForm()

    return render(request, 'registration/login.html', {'form': form})

def logout_view(request):
    logout(request)
    messages.info(request, "You have been logged out.")
    return redirect('home')
