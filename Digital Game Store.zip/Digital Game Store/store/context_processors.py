from .models import Cart, Wishlist, UserProfile

def store_context(request):
    cart_count = 0
    wishlist_count = 0
    user_wallet = 0.00
    
    if request.user.is_authenticated:
        # User profile wallet
        profile, created = UserProfile.objects.get_or_create(user=request.user)
        user_wallet = profile.wallet_balance
        
        # User cart count
        cart = Cart.objects.filter(user=request.user).first()
        if cart:
            cart_count = cart.items.count()
            
        # Wishlist count
        wishlist_count = Wishlist.objects.filter(user=request.user).count()
    else:
        # Session cart count
        session_key = request.session.session_key
        if session_key:
            cart = Cart.objects.filter(session_key=session_key).first()
            if cart:
                cart_count = cart.items.count()
                
    return {
        'cart_count': cart_count,
        'wishlist_count': wishlist_count,
        'user_wallet': user_wallet,
    }
