from django.contrib import admin
from .models import Genre, Tag, Game, GameScreenshot, UserProfile, Wishlist, Cart, CartItem, Order, OrderItem, Review

class GameScreenshotInline(admin.TabularInline):
    model = GameScreenshot
    extra = 3

@admin.register(Game)
class GameAdmin(admin.ModelAdmin):
    list_display = ('title', 'price', 'discount_percent', 'is_featured', 'is_trending', 'is_banner', 'release_date')
    list_filter = ('is_featured', 'is_trending', 'is_banner', 'genres')
    search_fields = ('title', 'developer', 'publisher')
    prepopulated_fields = {'slug': ('title',)}
    inlines = [GameScreenshotInline]
    filter_horizontal = ('genres', 'tags')

@admin.register(Genre)
class GenreAdmin(admin.ModelAdmin):
    list_display = ('name', 'slug', 'icon')
    prepopulated_fields = {'slug': ('name',)}

@admin.register(Tag)
class TagAdmin(admin.ModelAdmin):
    list_display = ('name', 'slug')
    prepopulated_fields = {'slug': ('name',)}

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'wallet_balance')

class OrderItemInline(admin.TabularInline):
    model = OrderItem
    readonly_fields = ('license_key',)
    extra = 0

@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ('order_number', 'user', 'total_amount', 'payment_method', 'status', 'created_at')
    list_filter = ('payment_method', 'status', 'created_at')
    search_fields = ('order_number', 'user__username')
    inlines = [OrderItemInline]

@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ('game', 'user', 'rating', 'is_recommended', 'created_at')
    list_filter = ('rating', 'is_recommended')

admin.site.register(Wishlist)
admin.site.register(Cart)
admin.site.register(CartItem)
