from django.urls import path
from . import views

urlpatterns = [
    path('', views.home_view, name='home'),
    path('catalog/', views.catalog_view, name='catalog'),
    path('game/<slug:slug>/', views.game_detail_view, name='game_detail'),
    path('cart/', views.cart_view, name='cart'),
    path('cart/add/<int:game_id>/', views.cart_add, name='cart_add'),
    path('cart/remove/<int:item_id>/', views.cart_remove, name='cart_remove'),
    path('wishlist/', views.wishlist_view, name='wishlist'),
    path('wishlist/toggle/<int:game_id>/', views.wishlist_toggle, name='wishlist_toggle'),
    path('checkout/', views.checkout_view, name='checkout'),
    path('order/<uuid:order_number>/', views.order_detail_view, name='order_detail'),
    path('library/', views.library_view, name='library'),
    path('profile/', views.profile_view, name='profile'),
    path('publisher/', views.publisher_dashboard, name='publisher_dashboard'),
    
    # Auth
    path('accounts/signup/', views.signup_view, name='signup'),
    path('accounts/login/', views.login_view, name='login'),
    path('accounts/logout/', views.logout_view, name='logout'),
]
